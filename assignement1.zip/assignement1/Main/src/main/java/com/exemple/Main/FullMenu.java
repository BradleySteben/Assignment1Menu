package com.exemple.Main;

public class FullMenu {

	private int mainid;
	
	private String mainname;
	
	private double mainprice;
	
	private String maindescription;
	
	private int sideid;
	
	private String sidename;
	
	private double sideprice;
	
	private String sidedescription;
	
	private int drinkid;
	
	private String drinkname;
	
	private double drinkprice;
	
	private String drinkdescription;
	
	private int dessertid;
	
	private String dessertname;
	
	private double dessertprice;
	
	private String dessertdescription;

	public FullMenu(int mainid, String mainname, double mainprice, String maindescription, int sideid, String sidename,
			double sideprice, String sidedescription, int drinkid, String drinkname, double drinkprice,
			String drinkdescription, int dessertid, String dessertname, double dessertprice,
			String dessertdescription) {
		super();
		this.mainid = mainid;
		this.mainname = mainname;
		this.mainprice = mainprice;
		this.maindescription = maindescription;
		this.sideid = sideid;
		this.sidename = sidename;
		this.sideprice = sideprice;
		this.sidedescription = sidedescription;
		this.drinkid = drinkid;
		this.drinkname = drinkname;
		this.drinkprice = drinkprice;
		this.drinkdescription = drinkdescription;
		this.dessertid = dessertid;
		this.dessertname = dessertname;
		this.dessertprice = dessertprice;
		this.dessertdescription = dessertdescription;
	}

	public FullMenu() {
		super();
	}

	public int getMainid() {
		return mainid;
	}

	public void setMainid(int mainid) {
		this.mainid = mainid;
	}

	public String getMainname() {
		return mainname;
	}

	public void setMainname(String mainname) {
		this.mainname = mainname;
	}

	public double getMainprice() {
		return mainprice;
	}

	public void setMainprice(double mainprice) {
		this.mainprice = mainprice;
	}

	public String getMaindescription() {
		return maindescription;
	}

	public void setMaindescription(String maindescription) {
		this.maindescription = maindescription;
	}

	public int getSideid() {
		return sideid;
	}

	public void setSideid(int sideid) {
		this.sideid = sideid;
	}

	public String getSidename() {
		return sidename;
	}

	public void setSidename(String sidename) {
		this.sidename = sidename;
	}

	public double getSideprice() {
		return sideprice;
	}

	public void setSideprice(double sideprice) {
		this.sideprice = sideprice;
	}

	public String getSidedescription() {
		return sidedescription;
	}

	public void setSidedescription(String sidedescription) {
		this.sidedescription = sidedescription;
	}

	public int getDrinkid() {
		return drinkid;
	}

	public void setDrinkid(int drinkid) {
		this.drinkid = drinkid;
	}

	public String getDrinkname() {
		return drinkname;
	}

	public void setDrinkname(String drinkname) {
		this.drinkname = drinkname;
	}

	public double getDrinkprice() {
		return drinkprice;
	}

	public void setDrinkprice(double drinkprice) {
		this.drinkprice = drinkprice;
	}

	public String getDrinkdescription() {
		return drinkdescription;
	}

	public void setDrinkdescription(String drinkdescription) {
		this.drinkdescription = drinkdescription;
	}

	public int getDessertid() {
		return dessertid;
	}

	public void setDessertid(int dessertid) {
		this.dessertid = dessertid;
	}

	public String getDessertname() {
		return dessertname;
	}

	public void setDessertname(String dessertname) {
		this.dessertname = dessertname;
	}

	public double getDessertprice() {
		return dessertprice;
	}

	public void setDessertprice(double dessertprice) {
		this.dessertprice = dessertprice;
	}

	public String getDessertdescription() {
		return dessertdescription;
	}

	public void setDessertdescription(String dessertdescription) {
		this.dessertdescription = dessertdescription;
	}
	
	
}
