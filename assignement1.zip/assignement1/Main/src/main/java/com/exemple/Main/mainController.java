package com.exemple.Main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import java.math.BigDecimal;




@RestController
public class mainController {
	
	
	@Autowired
	private mainRepository repository;
	
	@GetMapping("/main/id/{id}/side/{sideid}/drink/{drinkid}/dessert/{dessertid}")
	public FullMenu retrieveExchangeValue(@PathVariable int id,
			@PathVariable int sideid,
			@PathVariable int drinkid,
			@PathVariable int dessertid)throws IOException, JSONException {
		
		
		
		main food = repository.findById(id);
		
		FullMenu fullMenu = new FullMenu();
		
		fullMenu.setMainid(food.getId());
		fullMenu.setMainname(food.getName());
		fullMenu.setMainprice(food.getPrice());
		fullMenu.setMaindescription(food.getDescription());
		
		String url = "";
		
		if (sideid == 1) {
			url = "http://localhost:8004/sideDish/id/1";
		}
		if (sideid == 2) {
			url = "http://localhost:8004/sideDish/id/2";
		}
		if (sideid == 3) {
			url = "http://localhost:8004/sideDish/id/3";
		}
		
		JSONObject json = readJsonFromUrl(url);
	    fullMenu.setSideid((int)json.get("id")); 
	    fullMenu.setSidename((String) json.get("name"));
	    //fullMenu.setSideprice((double) json.get("price"));
	    fullMenu.setSidedescription((String)json.get("description"));
	    
	    if (drinkid == 1) {
			url = "http://localhost:8080/drinks/id/1";
		}
		if (drinkid == 2) {
			url = "http://localhost:8080/drinks/id/2";
		}
		if (drinkid == 3) {
			url = "http://localhost:8080/drinks/id/3";
		}
		
		json = readJsonFromUrl(url);
	    fullMenu.setDrinkid((int)json.get("id")); 
	    fullMenu.setDrinkname((String) json.get("name"));
	    //fullMenu.setDrinkprice((double)json.get("price"));
	    fullMenu.setDrinkdescription((String)json.get("description"));
	    
	    if (dessertid == 1) {
			url = "http://localhost:8005/dessert-information/id/1";
		}
		if (dessertid == 2) {
			url = "http://localhost:8005/dessert-information/id/2";
		}
		if (dessertid == 3) {
			url = "http://localhost:8005/dessert-information/id/3";
		}
		
		json = readJsonFromUrl(url);
	    fullMenu.setDessertid((int)json.get("id")); 
	    fullMenu.setDessertname((String) json.get("name"));
	    //fullMenu.setDessertprice((double)json.get("price"));
	    fullMenu.setDessertdescription((String)json.get("description"));
		
		
		
		return fullMenu;
		
		
		
	}

	private static String readAll(Reader rd) throws IOException {
	    StringBuilder sb = new StringBuilder();
	    int cp;
	    while ((cp = rd.read()) != -1) {
	      sb.append((char) cp);
	    }
	    return sb.toString();
	  }

	  public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
	    InputStream is = new URL(url).openStream();
	    try {
	      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
	      String jsonText = readAll(rd);
	      JSONObject json = new JSONObject(jsonText);
	      return json;
	    } finally {
	      is.close();
	    }
	  }

}