package com.exemple.Main;

import org.springframework.data.jpa.repository.JpaRepository;

public interface mainRepository extends JpaRepository<main, Long>{
	
	main findById(int id);
}
