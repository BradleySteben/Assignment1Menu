INSERT INTO MAIN (ID,NAME,PRICE,DESCRIPTION) values(1,'main1',9.99,'description1');
INSERT INTO MAIN (ID,NAME,PRICE,DESCRIPTION) values(2,'main2',12.99,'description2');
INSERT INTO MAIN (ID,NAME,PRICE,DESCRIPTION) values(3,'main3',7.99,'description3');