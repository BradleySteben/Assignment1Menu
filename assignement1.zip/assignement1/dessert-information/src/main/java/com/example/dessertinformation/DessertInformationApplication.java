package com.example.dessertinformation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DessertInformationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DessertInformationApplication.class, args);
	}

}
