package com.example.dessertinformation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DessertInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
