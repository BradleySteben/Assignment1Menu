package com.example.drinksservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrinksServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrinksServiceApplication.class, args);
	}

}
