INSERT INTO DRINK
(ID,DRINK_DESC,ENVIRONMENT,DRINK_NAME,DRINK_PRICE)
values
    (1,'good pepsicola','','pepsi','3.99'),
    (2,'good coca cola','','coke','2.49'),
    (3,'any type of juice','','juice','1.99'),
    (4,'cold beer','','beer','4.99');