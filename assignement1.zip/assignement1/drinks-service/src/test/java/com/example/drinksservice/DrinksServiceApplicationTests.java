package com.example.drinksservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrinksServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
