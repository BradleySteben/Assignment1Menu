package com.exemple.sideDish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SideDishApplication {

	public static void main(String[] args) {
		SpringApplication.run(SideDishApplication.class, args);
	}

}
