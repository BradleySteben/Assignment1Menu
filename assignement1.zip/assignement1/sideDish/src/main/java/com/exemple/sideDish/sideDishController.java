package com.exemple.sideDish;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class sideDishController {

	@Autowired
	private sideDishRepository repository;
	
	
	@GetMapping("/sideDish/id/{id}")
	public sideDish retrieveExchangeValue(@PathVariable int id) {
		
		
		sideDish side = repository.findById(id);
		
		return side;
		
	}
}
