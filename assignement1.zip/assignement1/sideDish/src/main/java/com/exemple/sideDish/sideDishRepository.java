package com.exemple.sideDish;

import org.springframework.data.jpa.repository.JpaRepository;

public interface sideDishRepository extends JpaRepository<sideDish, Long> {
	sideDish findById(int id);
}
