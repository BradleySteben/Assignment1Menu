INSERT INTO SIDE_DISH (ID,NAME,PRICE,DESCRIPTION) values(1,'side food1',9.99,'description1');
INSERT INTO SIDE_DISH (ID,NAME,PRICE,DESCRIPTION) values(2,'side food2',12.99,'description2');
INSERT INTO SIDE_DISH (ID,NAME,PRICE,DESCRIPTION) values(3,'side food2',7.99,'description3');