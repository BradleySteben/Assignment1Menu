package com.exemple.sideDish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SideDishApplicationTests {

	@Test
	void contextLoads() {
	}

}
